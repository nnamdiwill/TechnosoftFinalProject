package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.DarkSkyHomePage;
import org.junit.Assert;

public class DarkSkyFinalProject {

    DarkSkyHomePage dshp = new DarkSkyHomePage();

    @Given("^I am on darksky home page and create object for starting point.$")
    public void startingPoint(){

        dshp.createStartPoint();
    }

    @Then("^I verify the timelin is diplayed in 2 hour increments.$")
    public void verifyTimeLine(){
        dshp.incrementEveryHour();

    }

    @Given("^I am on darksky home page and will create an object.$")
    public void startOnDarkSky(){

        dshp.createStartPoint();

    }

    @When("^I expand todays timeline.$")
    public void showTimeLine() throws InterruptedException {

        dshp.scrolldown();
        dshp.clickTodaysWeatherButton();
    }

    @Then("^I verify lowest and highest temp is displayed correctly.$")
    public void verifyLowAndHighTemp(){

        Assert.assertTrue(true);
    }

    @Given("^I am on Darksky Home Page.$")
    public void darkSkyHomePage(){
        dshp.createStartPoint();

    }


    @Then("^I verify current temp is not greater or less then temps from daily timeline.$")
    public void verifyTempRange(){

        dshp.weatherComparison();
    }
}
