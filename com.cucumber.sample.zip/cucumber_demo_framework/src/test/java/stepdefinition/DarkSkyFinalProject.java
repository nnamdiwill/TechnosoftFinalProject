package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import framework.DarkSkyHomePage;

public class DarkSkyFinalProject {

    DarkSkyHomePage dshp = new DarkSkyHomePage();

    @Given("^I am on darksky home page and create object for starting point.$")
    public void startingPoint(){

        dshp.createStartPoint();
    }

    @Then("^I verify the timelin is diplayed in 2 hour increments.$")
    public void verifyTimeLine(){
        dshp.incrementEveryHour();

    }
}
