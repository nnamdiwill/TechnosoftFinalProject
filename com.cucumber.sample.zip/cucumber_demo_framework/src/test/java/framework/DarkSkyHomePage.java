package framework;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import stepdefinition.SharedSD;

import java.util.List;

public class DarkSkyHomePage extends BasePage {

  //  private By nowAsStartingPoint = By.xpath("//span[@class='Now']//*[text()='Now']");

    private By nowAsStartingPoint = By.xpath("//span[@class='Now']");

    private By everyHourafterStart = By.xpath("//span[@class='hour']");

    private By expandTodaysWeatherButton = By.xpath("//body[@class='forecast']/div[@id='week']/a[1]/span[2]");

    private By weatherSummary = By.xpath("//span[@class='summary swap']");

    private By weatherUpdates = By.xpath("//div[@class='temps']//span//span");



    public void createStartPoint(){
        WebElement nowAsStart = SharedSD.getDriver().findElement(nowAsStartingPoint);
    }

public void incrementEveryHour() {


   // List<WebElement> allHours = SharedSD.getDriver().findElements(everyHourafterStart);
    boolean hourIncrementsByTwo = false;
    for (int i = 1; i <= 12; i = i + 2) {
        if (i == 12) {
            for ( i = 2; i <= 12; i = i + 2) {

                hourIncrementsByTwo = true;
                String hours = SharedSD.getDriver().findElement(By.xpath("//span[@class=' " + i + "']")).toString();
                System.out.println("This prints i: " + i);
                Assert.assertTrue(true, "The time increments by two.");
            }

//        }
//   }
        }
    }
}

public void scrolldown() throws InterruptedException {
    WebElement Button = SharedSD.getDriver().findElement(expandTodaysWeatherButton);

     ((JavascriptExecutor) SharedSD.getDriver()).executeScript("arguments[0].scrollIntoView(true);",Button );


    Thread.sleep(2000);
}

public void clickTodaysWeatherButton(){
        clickOn(expandTodaysWeatherButton);
}

public void weatherComparison(){

        try {
            boolean forecastIshigherThanLowestValueAndLowerThanHighestValue = false;
            WebElement forecast = SharedSD.getDriver().findElement(weatherSummary);
            List<WebElement> weatherList = SharedSD.getDriver().findElements(weatherUpdates);


            int weatherListLength = weatherList.size();
            int minValue;
            int maxValue;

            for (int i = 0; i <= weatherListLength - 1; i++) {
                String findWeather = SharedSD.getDriver().findElements(By.xpath("//div[@class='temps']//span//span[" + i + "]")).toString();
                int convertI = Integer.parseInt(findWeather.trim());

                if (i <= convertI & i >= convertI) {
                    forecastIshigherThanLowestValueAndLowerThanHighestValue = true;

                    Assert.assertTrue(true);
                }

            }
        }catch (NumberFormatException nfe){
            System.out.println("Problem found");
        }

}
}
