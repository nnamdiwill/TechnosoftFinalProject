package framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import stepdefinition.SharedSD;

import java.util.List;

public class DarkSkyHomePage extends BasePage {

    private By nowAsStartingPoint = By.xpath("//span[@class='Now']//*[text()='Now']");

    private By everyHourafterStart = By.xpath("//span[@class='hour']");



    public void createStartPoint(){
        WebElement nowAsStart = SharedSD.getDriver().findElement(nowAsStartingPoint);
    }

public void incrementEveryHour(){



    List<WebElement> allHours = SharedSD.getDriver().findElements(everyHourafterStart);
//   for(int i = 0; i <= 24;  i = i+2){
//
//       String hours = SharedSD.getDriver().findElement(By.xpath("//span[@class=' " + i + "']")).toString();
//       System.out.println("This prints i: " + i);
//       Assert.assertTrue(true, "The time increments by two.");
//
    for(WebElement hours: allHours){

        boolean hourIncrementsByTwo = false;

        if(hourIncrementsByTwo){
            Assert.assertTrue(true,"The hours increment by 2");
        }
   }
}
}
